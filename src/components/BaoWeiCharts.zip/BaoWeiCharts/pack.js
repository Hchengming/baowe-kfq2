import BaoWeiCharts from './index.vue'

BaoWeiCharts.install = Vue => Vue.component('BaoWeiCharts', BaoWeiCharts)
export default BaoWeiCharts

// const ChartsTable = {
//   // 组件注册 install
//   install (Vue) {
//     Vue.component('BaoWeiCharts', BaoWeiCharts)
//   }
// }
//
// export default ChartsTable
